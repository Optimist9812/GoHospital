CREATE TRIGGER update_hospDept
AFTER INSERT ON doctor
FOR EACH ROW
  insert into hospdept(h_id,h_dept,h_room) values(new.h_id,new.h_dept,new.h_room);
